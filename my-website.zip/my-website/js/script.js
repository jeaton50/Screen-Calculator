function showMessage() {
  alert("Thanks for clicking!");
}
